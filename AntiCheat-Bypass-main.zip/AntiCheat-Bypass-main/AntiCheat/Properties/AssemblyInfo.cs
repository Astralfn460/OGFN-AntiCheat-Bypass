﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("4.26.1.0")]
[assembly: AssemblyTitle("Fortnite")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("1003")]
[assembly: AssemblyProduct("Unreal Engine")]
[assembly: AssemblyCopyright("Copyright Epic Games, Inc. All Rights Reserved")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("305db7c4-ab1d-402a-b5c3-916b7a186ec6")]
[assembly: AssemblyFileVersion("1.26.1")]
[assembly: NeutralResourcesLanguage("en")]
